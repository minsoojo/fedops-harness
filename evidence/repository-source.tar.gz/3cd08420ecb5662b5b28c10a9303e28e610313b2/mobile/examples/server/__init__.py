"""FedOps Mobile"""
